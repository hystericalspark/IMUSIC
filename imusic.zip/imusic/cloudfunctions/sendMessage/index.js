// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()
// 云函数入口函数
exports.main = async(event, context) => {
  try {

    const WXcontext = cloud.getWXContext()
    const templateId = 'H0qEluYsmkeDnVYqvTU5GqxI10qqjE0P1r3ogqjn7zI'
    return await cloud.openapi.subscribeMessage.send({
      touser: WXcontext.OPENID,
      page: `/pages/blog-comment/blog-comment?blogId=${event.blogId}`,
      lang: 'zh_CN',
      data: {
        phrase1: {
          value: '评价完成'
        },
        thing2: {
          value: event.content
        }
      },
      templateId: templateId,
      miniprogramState: 'developer'
    })
    console.log(result)
    return result
  } catch (err) {
    console.log(err)
    return err
  }
}