// pages/player/player.js
let musiclist=[]
//当前正在播放的歌曲的index
let nowPlayingIndex=0
//获取全局唯一的背景音乐管理器
const BackgroundAudioManager=wx.getBackgroundAudioManager()
const app=getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    picUrl:'',
    isPlaying:false,//false表示不播放，true表示正在播放，是一个状态
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log(options)
    musiclist=wx.getStorageSync('musiclist')
    nowPlayingIndex=options.index
    this._loadMusicDetail(options.musicid)

  },

  _loadMusicDetail(musicid){
    BackgroundAudioManager.stop()
    let music=musiclist[nowPlayingIndex]
    console.log(music)
    wx.setNavigationBarTitle({
      title: music.name,
    })
    this.setData({
      picUrl:music.al.picUrl,
      isPlaying:false
    })
    app.setplayingMusicId(musicid)

    wx.showLoading({
      title: '歌曲加载中',
    })

    wx.cloud.callFunction({
      name:'music',
      data:{
        $url:'musicUrl',
        musicId:musicid,
      }
    }).then((res)=>{
      console.log(res)
      console.log(JSON.parse(res.result))
      let result = JSON.parse(res.result)
      BackgroundAudioManager.src=result.data[0].url
      BackgroundAudioManager.title=music.name
      BackgroundAudioManager.coverImgUrl=music.al.picUrl
      BackgroundAudioManager.singer=music.ar[0].name
      BackgroundAudioManager.epname=music.al.name
      //保存播放历史
      this.savePlayHistory()

      this.setData({
        isPlaying: true
      })
      wx.hideLoading()

    })
  },
  togglePlaying(){
    //正在播放
    if(this.data.isPlaying){
      BackgroundAudioManager.pause()
    }else{
      BackgroundAudioManager.play()
    }
    this.setData({
      isPlaying:!this.data.isPlaying
    })
  },
onPrev(){
  nowPlayingIndex--
  if (nowPlayingIndex <0){
    nowPlayingIndex=musiclist.length-1

  }
  this._loadMusicDetail(musiclist[nowPlayingIndex].id)
},
onNext(){
  nowPlayingIndex++
  if (nowPlayingIndex == musiclist.length) {
    nowPlayingIndex = 0

  }
  this._loadMusicDetail(musiclist[nowPlayingIndex].id)
},
//保存播放历史
savePlayHistory(){
  const music=musiclist[nowPlayingIndex]
  const openid=app.globalData.openid
  const history=wx.getStorageSync(openid)
  let bHave=false
  for(let i=0,len=history.length;i<len;i++){
    if(history[i].id==music.id){
      bHave=true
      break
    }
  }
  if(!bHave){
    //在开头插入数据
    history.unshift(music)
    wx.setStorage({
      key: openid,
      data: history,
    })
  }
},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})